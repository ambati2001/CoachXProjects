CREATE TABLE Departments( DEPARTMENT_ID  int,  DEPARTMENT_NAME      varchar(500),  MANAGER_ID INT,  LOCATION_ID  INT)

CREATE TABLE Employees( EMPLOYEE_ID INT,  FIRST_NAME  VARCHAR(250),  LAST_NAME   VARCHAR(250),EMAIL VARCHAR(500), PHONE_NUMBER       VARCHAR(200),
 HIRE_DATE  DAtetime, JOB_ID     VARCHAR(200), SALARY INT,  COMMISSION_PCT INT,  MANAGER_ID INT,  DEPARTMENT_ID INT )

 CREATE TABLE Locations( LOCATION_ID  INT,  STREET_ADDRESS    VARCHAR(MAX), POSTAL_CODE VARCHAR(200),CITY  VARCHAR(200),  
 STATE_PROVINCE VARCHAR(500),  COUNTRY_ID VARCHAR(100) )

 CREATE TABLE job_grades( GRADE_LEVEL VARCHAR(50), LOWEST_SAL INT, HIGHEST_SAL INT )

 ---1-	write a SQL query to find the first name, last name, department number, and department name for each employee.
 SELECT Emp.FIRST_NAME, Emp.LAST_NAME, Emp.DEPARTMENT_ID,  D.DEPARTMENT_NAME  
 FROM Employees Emp
 INNER JOIN Departments D
 ON Emp.DEPARTMENT_ID = D.DEPARTMENT_ID

 --- 2-	write a SQL query to find the first name, last name, department, city, and state province for each employee.

 SELECT Emp.FIRST_NAME, Emp.LAST_NAME, Emp.DEPARTMENT_ID,  D.DEPARTMENT_NAME , Loc.CITY, Loc.STATE_PROVINCE  
 FROM Employees Emp
 INNER JOIN Departments D
 ON Emp.DEPARTMENT_ID = D.DEPARTMENT_ID
 INNER JOIN Locations Loc
 ON Loc.LOCATION_ID =D.LOCATION_ID

 -- 3- write a SQL query to find the first name, last name, salary, and job grade for all employees.
 SELECT Emp.FIRST_NAME, Emp.LAST_NAME, Emp.SALARY,
 CASE WHEN EMP.SALARY >= 1000 AND EMP.SALARY <3000 THEN 'A'
	WHEN EMP.SALARY >= 3000 AND EMP.SALARY <6000 THEN 'B'
	WHEN EMP.SALARY >= 6000 AND EMP.SALARY <10000 THEN 'C'
	WHEN EMP.SALARY >= 10000 AND EMP.SALARY <14999 THEN 'D'
	WHEN EMP.SALARY >= 15000 AND EMP.SALARY <25000 THEN 'E'
	WHEN EMP.SALARY >= 25000 AND EMP.SALARY <40000 THEN 'E'
	ELSE 'No Grade Or Out of Range' END AS [Job grade]
 FROM Employees Emp


 ---4-	write a SQL query to find all those employees who work in department ID 80 or 40. 
 --Return first name, last name, department number and department name.

  SELECT Emp.FIRST_NAME, Emp.LAST_NAME, Emp.DEPARTMENT_ID,  D.DEPARTMENT_NAME 
 FROM Employees Emp
 INNER JOIN Departments D
 ON Emp.DEPARTMENT_ID = D.DEPARTMENT_ID
 AND D.DEPARTMENT_ID IN (80, 40)