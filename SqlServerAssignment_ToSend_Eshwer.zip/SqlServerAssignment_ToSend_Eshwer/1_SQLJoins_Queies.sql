CREATE TABLE EmployeeDetail ( EmployeeID INT , FirstName VARCHAR(500), LastName VARCHAR(500), Salary
 INT, Department VARCHAR(200), Gender VARCHAR(50))


 CREATE TABLE ProjectDetail 
(ProjectDetailID INT,EmployeeDetailID INT, ProjectName VARCHAR(500) )

--1 Get Employee Name, Project Name order by firstname from "EmployeeDetail" and "ProjectDetail"for 
--those Employee which have assigned project already. 

SELECT Concat(Emp.FirstName,',',Emp.LastName) [Employee Name], Prj.ProjectName [Project Name]
FROM EmployeeDetail Emp 
INNER JOIN ProjectDetail Prj
ON Emp.EmployeeID =Prj.EmployeeDetailID
ORDER BY Emp.FirstName ASC


--2. Get Employee Name, Project Name order by firstname from "EmployeeDetail" and "ProjectDetail"for 
--those Employee even they have not assigned project.\
SELECT Concat(Emp.FirstName,',',Emp.LastName) [Employee Name], Prj.ProjectName [Project Name]
FROM EmployeeDetail Emp 
LEFT JOIN ProjectDetail Prj
ON Emp.EmployeeID =Prj.EmployeeDetailID
ORDER BY Emp.FirstName ASC


--3 Get all project name even they have not matching any employeeid, in left table, order by firstname from "EmployeeDetail" 
--and "ProjectDetail".
SELECT  Emp.FirstName, Emp.LastName , Prj.ProjectName 
FROM EmployeeDetail Emp 
RIGHT JOIN ProjectDetail Prj
ON Emp.EmployeeID =Prj.EmployeeDetailID
ORDER BY Emp.FirstName ASC

--4 Get Employee Record (Employeename, project name)from both tables ([EmployeeDetail],[ProjectDetail]),
--if no match found in any table then show null.
SELECT  Emp.FirstName, Emp.LastName,  Prj.ProjectName 
FROM EmployeeDetail Emp 
FULL JOIN ProjectDetail Prj
ON Emp.EmployeeID =Prj.EmployeeDetailID
ORDER BY Emp.FirstName ASC 
